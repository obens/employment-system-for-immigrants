<?php

  $nome = $_POST['nome']; 
  $sobrenome = $_POST['sobrenome'];
  $data_nascimento = $_POST['dt_nasc']; 
  $cpf = $_POST['cpf'];
  $sexo = $_POST['sexo']; 
  $profissao = $_POST['profissao'];
  $email = $_POST['email']; 
  $estado = $_POST['estado'];
  $cidade = $_POST['cidade']; 
  $bairro = $_POST['bairro'];
  $senha = $_POST['nome']; 
  $confirma_senha = $_POST['confisenha'];
  $mensagem = "";
  
  
  
  try {
    $conn = new PDO("mysql:host=localhost;dbname=pgp", "root", "");
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $insertion = "INSERT INTO imigrante(cpf,nome,email,sexo,profissao,telefone,nuncasa,rua,bairro,cidade,estado)VALUES($cpf,'$nome','$email','$sexo','$profissao','','','','$bairro','$cidade','$estado')";
    $conn->exec($insertion);
    $mensagem = " Sucesso! ";

  
    
    
  } catch(PDOException $e) {
    $mensagem = "Error de Cadastro !";
    echo $mensagem;
    echo "Connection failed: " . $e->getMessage();

  }


  


?>


<!DOCTYPE html>

<html>
       <head>
        <title></title>
       
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
   
        
        <link rel="stylesheet" href="styles.css"> 
        
        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
         <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@1,800&family=Roboto:ital,wght@0,400;1,300;1,400;1,500&display=swap" rel="stylesheet">
        
    </head>

    <body>

        <section id="section-1">
              <div class="mensagem" style="width:400px;background-color:white; color:#444;box-shadow:0 4px 8px 0 rgba(0, 0,0, 0.5);position:fixed; top:200px ;left:450px; padding:40px 0px 40px 120px">
               <div style="padding-left:40px">
               <svg xmlns="http://www.w3.org/2000/svg" style="color:#28B463 " width="32" height="32" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16">
             <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
            <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
             </svg>
               </div><br>
               <div style="padding-left:35px"> <?=$mensagem?><br><br></div>
                <p>Verifique o mensagem !</p><br>
                <div class="button-11">
                    <a href="/projetFinal/html/principal.html" style="height:50px;color:white;background-color:blue;font-size:20px;text-align:center;line-height:50px;border-radius:3px;width:230px;padding:5px 10px 5px 10px ;margin-left:40px">OK !</a>
                <div>
             </div>
        </section>
    </body>

</html>
