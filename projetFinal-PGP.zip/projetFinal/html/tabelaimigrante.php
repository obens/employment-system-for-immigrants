<?php

  $nome = $_POST['nome']; 
  $sobrenome = $_POST['sobrenome'];
  $data_nascimento = $_POST['dt_nasc']; 
  $cpf = $_POST['cpf'];
  $sexo = $_POST['sexo']; 
  $profissao = $_POST['profissao'];
  $email = $_POST['email']; 
  $estado = $_POST['estado'];
  $cidade = $_POST['cidade']; 
  $bairro = $_POST['bairro'];
  $senha = $_POST['nome']; 
  $confirma_senha = $_POST['confisenha'];







  try {
    $conn = new PDO("mysql:host=localhost;dbname=pgp", "root", "");
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    

    echo "Connected successfully";
    
  } catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
  }

  function inserir( $nome 
                  , $sobrenome 
                  , $data_nascimento
                  , $cpf
                  , $sexo 
                  , $profissao
                  , $email 
                  , $estado 
                  , $cidade 
                  , $bairro 
                  , $senha 
                  , $confirma_senha
                 ){
                     
                    $insertion = "INSERT INTO imigrante(cpf,nome,email,sexo,profissao,telefone,nuncasa,rua,bairro,cidade,estado)VALUES($cpf,$nome,$email,$sexo,$profissao,'','','',$bairro,$cidade,$estado)";
                    $conn->exec($insertion);

                }


$inserir = inserir( $nome 
                  , $sobrenome 
                  , $data_nascimento
                  , $cpf
                  , $sexo 
                  , $profissao
                  , $email 
                  , $estado 
                  , $bairro 
                  , $senha 
                  , $confirma_senha);
?>