
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
   
        
        <link rel="stylesheet" href="styles.css"> 
        
        
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@1,800&family=Roboto:ital,wght@0,400;1,300;1,400;1,500&display=swap" rel="stylesheet">
        
    </head>

    <body >

      <div class="divEmpresas-1">
        <div class="pagination">
          
          <a href="empresas1.php" class="active">1 </a>
          <a>Cadastro</a>
          <a href="empresas2.php" class="active">2</a>
          <a>Endereço</a>
          <a href="empresas3.php" class="active">3 </a>
          <a>Contato</a>
          <a href="empresas4.php" class="active" >4 </a>
          <a>Salvar</a>
          <br><br>
         
        </div>
       
            <form>

                <div class="tete">
                    <h1>Verificar os Dados</h1>
                </div>

                <div class="cadastraEmpresa">

                    
                        <form>

                         
                        
                              <h4>Dados Da Empresa</h4>
                        
                         
                              <p>CNPJ da Empresa :</p>
                              <p>Nome da Empresa :</p>
                              
                              <h4>Endereço</h4>
                              <p>Endereço :</p>
                              <p>Número :</p>
                              <p>Complemento :</p>
                              <p>Bairro :</p>
                              <p>Municipio :</p>
                              <p>UF :</p>

                              <h4>Contato</h4>
                              <p>Telefone :</p>
                              <p>Email :</p>
                              
                           


                        </form> 
                        
                            
                    
                        <br><br>
                        <a href="empresas3.html" class="button-5">Anterior</a>
                               
                        <a href="" class="button-4">Salvar</a>


                     
                       
                   
                       
                </div>
             
                

               


                

          
         
            </form>

        
          

      </div>

     
    </body>
</html>