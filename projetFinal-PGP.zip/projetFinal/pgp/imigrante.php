<?php
    include_once "imigranteB.php";
class imigrante{

    private $nome;
    private $sobrenome;
    private $data_nascimento ;
    private $cpf ;
    private $sexo;
    private $profissao;
    private $email;
    private $estado ;
    private $cidade ;
    private $bairro;
    private $senha ;
    private $confirma_senha;
  
   function receber_Valor() {
        $this->nome = isset($_POST['nome']) ? $_POST['nome'] : null;
        echo $this->nome;
        $this->sobrenome = isset($_POST['sobrenome']) ? $_POST['sobrenome'] : null;
        $this->data_nascimento  = isset($_POST['dtnasc']) ? $_POST['dt_nasc'] : null;
        $this->cpf= isset($_POST['cpf']) ? $_POST['cpf'] : null;
        $this->sexo = isset($_POST['sexo']) ? $_POST['sexo'] : null;
        $this->profissao  = isset($_POST['profissao']) ? $_POST['profissao'] : null;
        $this->email = isset($_POST['email']) ? $_POST['email'] : null;
        $this->estado = isset($_POST['estado']) ? $_POST['estado'] : null;
        $this->cidade  = isset($_POST['cidade']) ? $_POST['cidade'] : null;
        $this->bairro = isset($_POST['bairro']) ? $_POST['bairro'] : null;
        $this->senha= isset($_POST['senha']) ? $_POST['senha'] : null;
        $this->confirma_senha  = isset($_POST['confisenha']) ? $_POST['confisenha'] : null;
     
    }
    
    public function getNome(){
        return $this->nome;
    }
    
    public function setNome($nome){
        $this->nome=$nome;
    }
    
    
    
    public function getSobrenome(){
        return $this->sobrenome;
    }
    
    public function setSobrenome($sobrenome){
        $this->sobrenome=$sobrenome;
    }
    
    
    public function getData_nascimento(){
        return $this->data_nascimento;
    }
    
    public function setData_nascimento($nome){
        $this->data_nascimento=$data_nascimento;
    }
    
    
    public function getCpf(){
        return $this->cpf;
    }
    
    public function setCpf($cpf){
        $this->cpf=$cpf;
    }
    
    
    public function getSexo(){
        return $this->sexo;
    }
    
    public function setSexo($sexo){
        $this->sexo=$sexo;
    }
    
    
    public function getProfissao(){
        return $this->profissao;
    }
    
    public function setProfissao($profissao){
        $this->profissao=$profissao;
    }
    
    
    public function getEmail(){
        return $this->email;
    }
    
    public function setEmail($email){
        $this->email=$email;
    }
    
    public function getEstado(){
        return $this->estado;
    }
    
    public function setEstado($estado){
        $this->estado=$estado;
    }
    
    
    public function getCidade(){
        return $this->cidade;
    }
    
    public function setCidade($cidade){
        $this->cidade=$cidade;
    }
    
    
    public function getBairro(){
        return $this->bairro;
    }
    
    public function setBairro($bairro){
        $this->bairro=$bairro;
    }
    
    public function getSenha(){
        return $this->senha;
    }
    
    public function setSenha($senha){
        $this->senha=$senha;
    }
    
    
    public function getConfirma_senha(){
        return $this->confirma_senha;
    }
    
    public function setConfirma_senha($nome){
        $this->confirma_senha=$confirma_senha;
    }
    
}
$a=new imigrante();
$a->receber_Valor();
$b= new ImigranteB(); 
$b->inserir($a,$imigrante);


?>

