<?php
   include_once "conn.php";
   include_once "imigrante.php";


class Imigrante{

        public $conexao;
        public $insercao;
        
      /*  public function construct(){
            echo "ghgkfjhk";
            $this->conexao=conecta();
            
           
        }*/
        public function imprimi(){
            echo "hdbsb";
        }
        /*
        
        public function listar(){
            try{
                $query=$this->conexao->("select*from imigrante order by nome");
                $query->execute();
                $registros=$query->fechALL(PDO::FETCH_CLASS,"imigrante")
                return $registros;
            
            
            } 
            catch(PDOException $e) {
                echo "Error no acesso aos dados: ".$e->getMessage();
            }

        }

        
        
       
        public function buscar($cod){
        try{
            $query= $this->conexao->prepare("select * from imigrante where  codigo=:cod");
            $query->binParam(":cod",$cod);
            $query->execute();
            $registro=$query->fetch(PDO::FETCH_CLASS,"imigrante");
            return $registro;

        }
        catch(PDOException $e){
            echo "erro no acesso aos dados: ". $e->getMessage();
        }
            
        }

        */

        /*public function inserir(imigrante $imigrante){
            
        
        
           try{
                $insertion = "INSERT INTO imigrante(cpf,nome,email,sexo,profissao,telefone,nuncasa,rua,bairro,cidade,estado)VALUES(7133,'novocpf','demostheneromane@yahoo.fr','M','Estudante','4642436','219','Rouxinol','Efapi','Chapeco Sc','SC')";
                $this->conexao->exec($insertion);
                echo "jhdshk";
            }

            catch(PDOException $e){
                echo "erro no acesso aos dados: ". $e->getMessage();
            } 
            



        }
      
        /*

        public function alterar(imigrante $imigran){

            try{
                $query= $this->conexao->prepare("update imigrante set nome= :n,sobrenome=;s,cpf=:f where codigo =:cod");
                $query->binValue(":n",$imigrante->getNome());
                $query->binValue(":s",$imigrante->getSobrenome());
                $query->binValue(":f",$imigrante->getCpf());
                $query->binValue(":cod",$imigrante->getCodigo());
                return $query->execute();
            
        
            }
            catch(PDOException $e){
                echo "erro no acesso aos dados: ". $e->getMessage();
            }
            
         


            
        }

        
                    public function excluir($cod){


                        try{
                            $query= $this->conexao->prepare("delete from imigrante where codigo =:cod");
                        
                            $query->binValue(":cod",$cod);
                            return $query->execute();
                        
                    
                        }
                        catch(PDOException $e){
                            echo "erro no acesso aos dados: ". $e->getMessage();
                        }

                    */
                        


            
        









}  

$a = new Imigrante();

$a->imprimi();
/*
$b= new imigrante();

$a->inserir($b, $imigrante);*/





?>


