

<?php
$servername = "localhost";
$username = "root";
$password = "";


function conecta(){
    try {
      $conn = new PDO("mysql:host=localhost;dbname=pgp", "root", "");
      // set the PDO error mode to exception
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      
  
      echo "Connected successfully";
      
    } catch(PDOException $e) {
      echo "Connection failed: " . $e->getMessage();
    }
  
    return $conn;
}





$a = conecta(); 
echo "funcao";
echo $a
?>



