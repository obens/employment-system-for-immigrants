<?php

class imigrante{
    private $nome
    private $sobrenome
    private $data_nascimento
    private $cpf
    private $sexo
    private $profissao
    private $email
    private $estado
    private $cidade
    private $bairro
    private $senha
    private $confirma_senha
}

public function getNome(){
    return $this->nome;
}

public function setNome($nome){
    $this->nome=$nome;
}



public function getSobrenome(){
    return $this->sobrenome;
}

public function setSobrenome($sobrenome){
    $this->sobrenome=$sobrenome;
}


public function getData_nascimento(){
    return $this->data_nascimento;
}

public function setData_nascimento($nome){
    $this->data_nascimento=$data_nascimento;
}


public function getCpf(){
    return $this->cpf;
}

public function setCpf($cpf){
    $this->cpf=$cpf;
}


public function getSexo(){
    return $this->sexo;
}

public function setSexo($sexo){
    $this->sexo=$sexo;
}


public function getProfissao(){
    return $this->profissao;
}

public function setProfissao($profissao){
    $this->profissao=$profissao;
}


public function getEmail(){
    return $this->email;
}

public function setEmail($email){
    $this->email=$email;
}

public function getEstado(){
    return $this->estado;
}

public function setEstado($estado){
    $this->estado=$estado;
}


public function getCidade(){
    return $this->cidade;
}

public function setCidade($cidade){
    $this->cidade=$cidade;
}


public function getBairro(){
    return $this->bairro;
}

public function setBairro($bairro){
    $this->bairro=$bairro;
}

public function getSenha(){
    return $this->senha;
}

public function setSenha($senha){
    $this->senha=$senha;
}


public function getConfirma_senha(){
    return $this->confirma_senha;
}

public function setConfirma_senha($nome){
    $this->confirma_senha=$confirma_senha;
}
