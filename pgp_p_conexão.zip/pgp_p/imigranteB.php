<?php
   require_once "conexao.php";
   require_once "imigrante.php";


class ImigranteB{

        public $conexao;


        public function_construct(){
            $this->conexao=conexao::conecta();

        }
        /*
        
        public function listar(){
            try{
                $query=$this->conexao->("select*from imigrante order by nome");
                $query->execute();
                $registros=$query->fechALL(PDO::FETCH_CLASS,"imigrante")
                return $registros;
            
            
            } 
            catch(PDOException $e) {
                echo "Error no acesso aos dados: ".$e->getMessage();
            }

        }

        */
        
       /*
        public function buscar($cod){
        try{
            $query= $this->conexao->prepare("select * from imigrante where  codigo=:cod");
            $query->binParam(":cod",$cod);
            $query->execute();
            $registro=$query->fetch(PDO::FETCH_CLASS,"imigrante");
            return $registro;

        }
        catch(PDOException $e){
            echo "erro no acesso aos dados: ". $e->getMessage();
        }
            
        }

        */

        public function inserir(imigrante $imigran){

            try{
                $query= $this->conexao->prepare("insert into imigrante values(NULL:n,:i,:f)");
                $query->binValue(":n",$imigrante->getNome());
                $query->binValue(":s",$imigrante->getSobrenome());
                $query->binValue(":f",$imigrante->getCpf());
                return $query->execute();
            
        
            }
            catch(PDOException $e){
                echo "erro no acesso aos dados: ". $e->getMessage();
            }
            



        }
      
        /*

        public function alterar(imigrante $imigran){

            try{
                $query= $this->conexao->prepare("update imigrante set nome= :n,sobrenome=;s,cpf=:f where codigo =:cod");
                $query->binValue(":n",$imigrante->getNome());
                $query->binValue(":s",$imigrante->getSobrenome());
                $query->binValue(":f",$imigrante->getCpf());
                $query->binValue(":cod",$imigrante->getCodigo());
                return $query->execute();
            
        
            }
            catch(PDOException $e){
                echo "erro no acesso aos dados: ". $e->getMessage();
            }
            
         


            
        }

        */

                /*
                    public function excluir($cod){


                        try{
                            $query= $this->conexao->prepare("delete from imigrante where codigo =:cod");
                        
                            $query->binValue(":cod",$cod);
                            return $query->execute();
                        
                    
                        }
                        catch(PDOException $e){
                            echo "erro no acesso aos dados: ". $e->getMessage();
                        }

                    */
                        


            
        }









}  
